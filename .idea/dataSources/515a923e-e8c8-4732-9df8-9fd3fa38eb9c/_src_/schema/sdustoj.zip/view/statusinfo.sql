CREATE VIEW statusinfo AS
  SELECT
    `so`.`solution_id`                   AS `solution_id`,
    `so`.`problem_id`                    AS `problem_id`,
    `so`.`user_id`                       AS `user_id`,
    `so`.`time`                          AS `time`,
    `so`.`memory`                        AS `memory`,
    `so`.`in_date`                       AS `in_date`,
    `so`.`language`                      AS `language`,
    `so`.`ip`                            AS `ip`,
    `so`.`contest_id`                    AS `contest_id`,
    `so`.`valid`                         AS `valid`,
    `so`.`num`                           AS `num`,
    `so`.`code_length`                   AS `code_length`,
    `so`.`judgetime`                     AS `judgetime`,
    `so`.`is_sim`                        AS `is_sim`,
    `sdustoj`.`status`.`status_id`       AS `status_id`,
    `sdustoj`.`status`.`status`          AS `status`,
    `sdustoj`.`language`.`language_name` AS `language_name`
  FROM ((`sdustoj`.`solution` `so` LEFT JOIN `sdustoj`.`status`
      ON ((`so`.`result` = `sdustoj`.`status`.`result_id`))) LEFT JOIN `sdustoj`.`language`
      ON ((`so`.`language` = `sdustoj`.`language`.`language`)));
