CREATE VIEW archive AS
  SELECT
    `so`.`user_id`                      AS `user_id`,
    `so`.`problem_id`                   AS `problem_id`,
    `so`.`solution_id`                  AS `solution_id`,
    `sdustoj`.`language`.`language_ext` AS `language_ext`,
    `sdustoj`.`status`.`status`         AS `result`,
    `sdustoj`.`source_code`.`source`    AS `code`
  FROM (((`sdustoj`.`solution` `so` LEFT JOIN `sdustoj`.`language`
      ON ((`so`.`language` = `sdustoj`.`language`.`language`))) LEFT JOIN `sdustoj`.`status`
      ON ((`so`.`result` = `sdustoj`.`status`.`result_id`))) LEFT JOIN `sdustoj`.`source_code`
      ON ((`so`.`solution_id` = `sdustoj`.`source_code`.`solution_id`)));
