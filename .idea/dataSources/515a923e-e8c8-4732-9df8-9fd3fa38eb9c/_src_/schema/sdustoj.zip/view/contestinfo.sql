CREATE VIEW contestinfo AS
  SELECT
    `sdustoj`.`contest`.`contest_id`          AS `contest_id`,
    `sdustoj`.`contest`.`title`               AS `title`,
    `sdustoj`.`contest`.`start_time`          AS `start_time`,
    `sdustoj`.`contest`.`end_time`            AS `end_time`,
    `sdustoj`.`contest`.`defunct`             AS `defunct`,
    `sdustoj`.`contest`.`points`              AS `points`,
    `sdustoj`.`contest`.`langmask`            AS `langmask`,
    `sdustoj`.`contest`.`contest_mode`        AS `contest_mode`,
    `sdustoj`.`contest_privilege`.`privilege` AS `privilege`,
    `sdustoj`.`language`.`language_name`      AS `language`
  FROM ((`sdustoj`.`contest`
    LEFT JOIN `sdustoj`.`contest_privilege`
      ON ((`sdustoj`.`contest`.`private` = `sdustoj`.`contest_privilege`.`private_id`))) LEFT JOIN `sdustoj`.`language`
      ON ((`sdustoj`.`contest`.`langmask` = `sdustoj`.`language`.`language`)));
