CREATE VIEW sim_info AS
  SELECT
    `sdustoj`.`sim`.`s_id`         AS `s_id`,
    `sdustoj`.`sim`.`sim_s_id`     AS `sim_s_id`,
    `sdustoj`.`sim`.`sim`          AS `sim`,
    `sdustoj`.`solution`.`user_id` AS `user_id`
  FROM (`sdustoj`.`sim`
    LEFT JOIN `sdustoj`.`solution` ON ((`sdustoj`.`sim`.`sim_s_id` = `sdustoj`.`solution`.`solution_id`)));
